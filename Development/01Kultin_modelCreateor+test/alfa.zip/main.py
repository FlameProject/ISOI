# main.py
import tkinter as tk
from gui import OCRAppEnhanced
import os

def main():
    print("=" * 70)
    print("🎯 OCR СИСТЕМА РАСПОЗНАВАНИЯ ТЕКСТА - УЛУЧШЕННАЯ ВЕРСИЯ")
    print("=" * 70)
    print("\n🚀 ОСНОВНЫЕ УЛУЧШЕНИЯ:")
    print("  1. Минимальная морфология - сохраняем тонкие линии")
    print("  2. Интеллектуальное разделение слипшихся символов")
    print("  3. Восстановление 'съеденных' букв (без ximgproc)")
    print("  4. Автоматическая коррекция контраста для каждого символа")
    print("  5. Показ альтернативных вариантов распознавания")
    print("  6. Интеллектуальное определение пробелов")
    print()
    
    # Проверяем наличие модели
    model_files = [f for f in os.listdir('.') if f.endswith('.pth') and '24x24' in f]
    if not model_files:
        print("⚠️  ВНИМАНИЕ: Модель не найдена!")
        print("   Сначала обучите модель:")
        print("   python CreateModel.py")
        print("\n   Доступные файлы .pth:")
        for f in os.listdir('.'):
            if f.endswith('.pth'):
                print(f"   - {f}")
        print()
    
    # Запускаем GUI
    root = tk.Tk()
    app = OCRAppEnhanced(root)
    root.mainloop()

if __name__ == "__main__":
    main()